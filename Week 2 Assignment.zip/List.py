Employees = ['Roger', 'Kate', 'Daren', 'Ralph', 'Suzan']

Employees[0] = 'Roger Easterly, 123121234, 123-123- \n ' \
               '1234, roger@mail.com, $6000'
Employees[1] = 'Kate_spade, 234567890, 123-234- \n ' \
               '3456, kate@mail.com, $6000'
Employees[2] = 'Daren_Klien, 098765432, 123-234- \n ' \
               '4567, daren@mail.com, $6500'
Employees[3] = 'Ralph_Demarco, 12345678,123-234- \n ' \
               '5678, ralph@mail.com, $7000'
Employees[4] = 'Suzan_Wright, 123457654, 123-234- \n ' \
               '6789, suzan@mail.com,$8000'

print(Employees[0])



